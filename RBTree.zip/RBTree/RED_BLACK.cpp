#include <iostream>
#include "Red_black_tree.h"
using namespace std;

int main() {

    Red_black_tree rbtree;

    // Inserting values into Red-Black Tree
    rbtree.Insert(7);
    rbtree.Insert(3);
    rbtree.Insert(18);
    rbtree.Insert(10);
    rbtree.Insert(22);
    rbtree.Insert(8);
    rbtree.Insert(11);
    rbtree.Insert(26);
    rbtree.Insert(2);
    rbtree.Insert(6);

    // Printing Red-Black Tree
    rbtree.inorder();

    // Deleting nodes from Red-Black Tree
    cout << "After deleting 18:" << endl;
    rbtree.DeleteNode(18);
    rbtree.inorder ();

    cout << "After deleting 11:" << endl;
    rbtree.DeleteNode (11);
    rbtree.inorder ();

    cout << "After deleting 3:" << endl;
    rbtree.DeleteNode (3);
    rbtree.inorder();

    return 0;
}