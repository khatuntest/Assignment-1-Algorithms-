#include <iostream>
using namespace std;

//enum Color { RED, BLACK };
#ifndef ADVANSED_DS_RED_BLACK_TREE_H
#define ADVANSED_DS_RED_BLACK_TREE_H

class Red_black_tree {
private:
    struct Node {
        int data;
        char color; // 'R' -> red, 'B' -> black
        Node *left, *right, *parent;
        Node(int data) {
            this->data = data;
            left = nullptr;
            right = nullptr;
            parent = nullptr;
            this->color = 'R'; // Default color is red
        }
    };
    Node* root;
public:
    Red_black_tree();
    void rotateLeft(Node* x);
    void rotateRight(Node* x);
    void FixInsert(Node* node);
    void FixDelete(Node* node);
    void transplant(Node* original, Node* new_node );
    Node* minValueNode(Node* node);
    void inorderHelper(Node* node);
    void Insert(const int& n);
    void DeleteNode(const int& data);
    void inorder();
};
#endif //ADVANSED_DS_RED_BLACK_TREE_H
