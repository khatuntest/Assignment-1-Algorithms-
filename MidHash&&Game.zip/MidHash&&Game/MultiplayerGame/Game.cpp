#include <iostream>
#include <vector>
#include "Game.h"
using namespace std;

Game :: Game(int levels ){
    list = new SkipList(levels );
}
void Game :: addPlayer(int id, int score){
    list->insert(id , score);
    cout<<"Player "<<id <<" joined the game with score "<<score<<".\n";
}
void Game :: removePlayer(int id){
    list->remove(id);
    cout<<"Player "<<id<<" left the game.\n";
}
void Game :: updateScore(int id, int newScore){
    list->remove(id);
    list->insert(id,newScore);
    cout<<"Player "<<id<<"'s score updated to "<<newScore<< ".\n";
}
void Game :: leaderboard(int playerNumber){
    cout<<"Top "<<playerNumber<< " Players:\n";
    SkipNode * current = list->getHeader->forward[0];
    vector<pair<int,int>>vc;
    while(current && playerNumber > 0){
        vc.push_back({current->key , current->value});
        current= current->forward[0];
        playerNumber--;
    }
    for (auto& player : vc) {
        cout <<"Player ID: "<<player.first<<", Score: "<<player.second<<"\n";
    }
    if (vc.size() < playerNumber) {
        cout<<"Note: Only "<<vc.size()<<" players are available.\n";
    }
}
void Game :: viewScore(int id){
    SkipNode* player = list->search(id);
    if (player) {
        cout<<"Player "<<id<<"'s score is "<<player->value<< ".\n";

    }
    else {
        cout<<"Player "<<id<<" not found in the game.\n";
    }
}
Game :: ~Game(){
    delete list;
}
