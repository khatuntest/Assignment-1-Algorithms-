
#ifndef MULTIPLAYERGAME_GAME_H
#define MULTIPLAYERGAME_GAME_H


class Game {
private:
    SkipList * list;
public:
    Game(int levels );
    void addPlayer(int id, int score);
    void removePlayer(int id);
    void updateScore(int id, int newScore);
    void leaderboard(int playerNumber);
    void viewScore(int playerId);
    ~Game();

};


#endif //MULTIPLAYERGAME_GAME_H
