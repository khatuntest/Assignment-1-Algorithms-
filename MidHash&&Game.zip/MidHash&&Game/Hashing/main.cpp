#include <iostream>
using namespace std;
int midSquareHash(int key, int size){
    long long square = key*key;
    string sqStr= to_string(square);
    int midStart=(sqStr.size())/2-1;
    string ans=sqStr.substr(midStart , 2);
    int hash=stoi(ans);
    return hash%size;
}

int main() {
    cout<<"Enter Table Size.\n";
    int size;
    cin>>size;
    int key;
    while(true){
        cout<<"1. Enter your key\n"
              "2. Enter -1 to exist\n";
        cin>>key;
        if (key != -1){
            int hashValue = midSquareHash(key,size);
            cout << "Hash value for key " << key << " is: " << hashValue << endl;
        }
        else if (key == -1){
            cout<<"Good Luck...\n";
            return 0;
        }
        else {
            cout<<"The Key is not true.....\n"
                  "Try again.\n";
        }
    }
}
